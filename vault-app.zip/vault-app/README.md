# VAULT — File Upload Service

A minimal React + FastAPI application that accepts a file (≤ 1 MB) and returns a unique receipt number.

---

## Project structure

```
app/
├── backend/
│   ├── main.py
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── main.jsx
        ├── App.jsx
        └── index.css
```

---

## Local setup

### 1 — Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Environment variables (optional — defaults shown)
export UPLOAD_DIR=/tmp/uploads   # directory where files are stored

uvicorn main:app --host 0.0.0.0 --port 8000
```

### 2 — Frontend (dev server)

```bash
cd frontend
npm install

# Environment variable (optional)
export VITE_BASE_PATH=""          # e.g. /vault  — no trailing slash

npm run dev
```

Open http://localhost:5173 (or whatever port Vite chooses).

The Vite dev server proxies `/api/*` → `http://127.0.0.1:8000/api/*` automatically.

### 3 — Frontend (production build)

```bash
cd frontend
VITE_BASE_PATH=/vault npm run build   # outputs to frontend/dist/
```

Serve `dist/` as static files from nginx (see below).

---

## Environment variables

| Variable         | Component | Default       | Purpose                              |
|------------------|-----------|---------------|--------------------------------------|
| `UPLOAD_DIR`     | Backend   | `/tmp/uploads`| Directory where uploaded files land  |
| `VITE_BASE_PATH` | Frontend  | *(empty)*     | URL prefix when app is sub-pathed    |

> **One-place configuration**: change `VITE_BASE_PATH` at build time and the nginx `location` block below to move the whole app to any sub-path.

---

## uploads.csv

Created automatically in `$UPLOAD_DIR/uploads.csv`. Format:

```
receipt,filename,size_bytes,timestamp
3f2a1b…,report.pdf,204800,2024-01-15T10:30:00.123456
```

A new row is appended for every successful upload.

---

## Sample nginx configuration

```nginx
# /etc/nginx/sites-available/vault
server {
    listen 80;
    server_name example.com;

    # ── Static frontend ────────────────────────────────────────────────
    location /vault/ {
        alias /var/www/vault/dist/;
        try_files $uri $uri/ /vault/index.html;
    }

    # ── FastAPI backend ────────────────────────────────────────────────
    location /vault/api/ {
        proxy_pass         http://127.0.0.1:8000/api/;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;

        # Allow up to 1 MB (nginx default is 1m, explicit for clarity)
        client_max_body_size 1m;
    }
}
```

> If you want the app at the root path (`/`), set `VITE_BASE_PATH=""` and adjust the nginx `location` blocks to `/` and `/api/` respectively.

---

## API

### `POST /api/upload`

| Field    | Type          | Description              |
|----------|---------------|--------------------------|
| `file`   | `multipart`   | File to upload (≤ 1 MB)  |

**Success (200)**
```json
{ "receipt": "3f2a1b4c-8d9e-4f0a-b1c2-d3e4f5a6b7c8" }
```

**Error (413)**
```json
{ "detail": "File exceeds the 1 MB limit." }
```

---

## Security notes

- No endpoint exists to list, download, or delete stored files.
- CORS is open (`*`) — restrict `allow_origins` in `main.py` for production.
- For production, run uvicorn behind nginx (never expose port 8000 publicly).
